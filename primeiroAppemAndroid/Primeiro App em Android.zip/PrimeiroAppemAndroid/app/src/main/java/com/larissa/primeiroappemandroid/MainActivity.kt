package com.larissa.primeiroappemandroid

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    lateinit var textoGlobal : TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        textoGlobal = findViewById(R.id.texto)
//        exibirTexto()

        var nome : String = "Larissa"

//        textoGlobal = findViewById<TextView>(R.id.texto)
//        texto.text = "Oi, este é meu primeiro app!"
        exibirTexto(nome)

    }
    fun exibirTexto(nome: String){
        textoGlobal.text = "Este é o primeiro app da $nome!"
    }
}